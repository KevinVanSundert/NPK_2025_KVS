ds_npk = read.csv("npk_dataset.csv",header = T)

library(tidyverse)
library(ggplot2)
library(ggtern)
library(MASS)
library(patchwork)

# Habitat types

  ds_npk_filtered = ds_npk[!is.na(ds_npk$Habitat), ]
  
  ds_npk_figuremaking = ds_npk_filtered %>%
    mutate(Line1 = NA) %>%
    mutate(Line2 = NA) %>%
    mutate(Line3 = NA) %>%
    add_row(P_relative = c(1,32.25/100,0,50.375/100,0,36.6/100),N_relative = c(0,46/100,1,33.435/100,0,51.7/100),K_relative = c(0,21.75/100,0,16.19/100,1,11.7/100),Line1 = c(1,1,NA,NA,NA,NA),Line2 = c(NA,NA,1,1,NA,NA),Line3 = c(NA,NA,NA,NA,1,1))
  
  ds_npk_figuremaking$Habitat = factor(ds_npk_figuremaking$Habitat,
                                        levels = c("calcareous springs",
                                                   "fens",
                                                   "bogs",
                                                   "wet dune slacks",
                                                   "fen meadows",
                                                   "Nardus grasslands",
                                                   "wet heathlands",
                                                   "dry calcareous grasslands",
                                                   "dry dunes",
                                                   "dry heathlands",
                                                   "wet eutrophic marshes",
                                                   "moist grasslands",
                                                   "dry grasslands"))
  
  droplastsix = tail(which(is.na(ds_npk_figuremaking$Habitat)), 6)
  
  tgraph <- ggtern(data=ds_npk_figuremaking,aes(x=P_relative,y=N_relative,z=K_relative))+ 
    geom_point(aes(fill=Habitat),color="black",size=2,shape=21) +
    geom_point(data=ds_npk_figuremaking[droplastsix,], aes(x=P_relative, y=N_relative, z=K_relative),
               color="white", size=2, shape=21) +
    theme_rgbw() +
    theme(legend.justification=c(0,1), legend.position=c(0,1), plot.tag = element_text(face = "bold",size = 24), text = element_text(size = 17),
          legend.key = element_blank(),legend.background = element_rect(fill = "transparent"),legend.text = element_text(size = 10),
          legend.text.align = 0) + 
    guides(fill = guide_legend(order = 1), alpha = guide_legend(order = 2), color = "none") +
    labs(fill = "Habitat type")+
    Tlab("",labelarrow="10P/(N+10P+K)")+
    Tlab("",labelarrow="N/(N+10P+K)")+
    Llab("",labelarrow="10P/(N+10P+K)")+
    Rlab("",labelarrow="K/(N+10P+K)")+
    geom_path(aes(size=Line1),color="black")+
    geom_path(aes(size=Line2),color="black")+
    geom_path(aes(size=Line3),color="black")+
    geom_path(aes(size=Line3*10),color="black",alpha=0)+
    guides(fill = guide_legend(order = 1), alpha = guide_legend(order = 2), color = "none", size = "none")+
    scale_fill_discrete(breaks = c("calcareous springs",
                                   "fens",
                                   "bogs",
                                   "wet dune slacks",
                                   "fen meadows",
                                   "Nardus grasslands",
                                   "wet heathlands",
                                   "dry calcareous grasslands",
                                   "dry dunes",
                                   "dry heathlands",
                                   "wet eutrophic marshes",
                                   "moist grasslands",
                                   "dry grasslands"),
                        labels = c("calcareous springs",
                                   "fens",
                                   "bogs",
                                   "wet dune slacks",
                                   "fen meadows",
                                   expression(italic("Nardus") ~ "grasslands"),
                                   "wet heathlands",
                                   "dry calcareous\ngrasslands",
                                   "dry dunes",
                                   "dry\nheathlands",
                                   "wet\neutrophic\nmarshes",
                                   "moist grasslands",
                                   "dry grasslands")) +
    labs(tag = "(a)") +
    annotate("text", x=1.8, y=0.3, z=1.75, label="N limitation", size=6, color="black") +
    annotate("text", x=0.07, y=0.55, z=0.53, label="P/P+N limitation", size=6, color="black", angle = -60) +
    annotate("text", x=0.57, y=0.67, z=0.04, label="K/K+N limitation", size=6, color="black", angle = 60)

# Moisture EIV

ds_npk_filtered = ds_npk[!is.na(ds_npk$Moisture_ell), ]

ds_npk_figuremaking = ds_npk_filtered %>%
  mutate(Line1 = NA) %>%
  mutate(Line2 = NA) %>%
  mutate(Line3 = NA) %>%
  add_row(P_relative = c(1,32.25/100,0,50.375/100,0,36.6/100),N_relative = c(0,46/100,1,33.435/100,0,51.7/100),K_relative = c(0,21.75/100,0,16.19/100,1,11.7/100),Line1 = c(1,1,NA,NA,NA,NA),Line2 = c(NA,NA,1,1,NA,NA),Line3 = c(NA,NA,NA,NA,1,1))

droplastsix = tail(which(is.na(ds_npk_figuremaking$Moisture_ell)), 6)
moist <- ggtern(data=ds_npk_figuremaking,aes(x=P_relative,y=N_relative,z=K_relative))+ 
  geom_point(aes(fill=Moisture_ell),color="black",size=2,shape=21) +
  geom_point(data=ds_npk_figuremaking[droplastsix,], aes(x=P_relative, y=N_relative, z=K_relative),
             color="white", size=2, shape=21) +
  scale_fill_gradient(low="yellow",high="red",na.value = NA) +
  scale_color_gradient(low="yellow",high="red",na.value = NA) +
  theme_rgbw() +
  theme(legend.justification=c(0,1), legend.position=c(0,1),plot.tag = element_text(face = "bold",size = 24),text = element_text(size = 17)) + 
  guides(fill = guide_colorbar(order=1),alpha= guide_legend(order=2),color="none") +
  labs(fill = "Moisture EIV")+
  Tlab("",labelarrow="10P/(N+10P+K)")+
  Tlab("",labelarrow="N/(N+10P+K)")+
  Llab("",labelarrow="10P/(N+10P+K)")+
  Rlab("",labelarrow="K/(N+10P+K)")+
  geom_path(aes(size=Line1),color="black")+
  geom_path(aes(size=Line2),color="black")+
  geom_path(aes(size=Line3),color="black")+
  geom_path(aes(size=Line3*10),color="black",alpha=0)+
  guides(fill = guide_colorbar(order = 1),alpha = guide_legend(order = 2),color = "none",size = "none") +
  labs(tag = "(b)") +
  annotate("text", x=1.8, y=0.3, z=1.75, label="N limitation", size=6, color="black") +
  annotate("text", x=0.07, y=0.55, z=0.53, label="P/P+N limitation", size=6, color="black", angle = -60) +
  annotate("text", x=0.57, y=0.67, z=0.04, label="K/K+N limitation", size=6, color="black", angle = 60)

# Soil pH class

ds_npk_filtered = ds_npk[!is.na(ds_npk$pH_class), ]

ds_npk_figuremaking = ds_npk_filtered %>%
  mutate(Line1 = NA) %>%
  mutate(Line2 = NA) %>%
  mutate(Line3 = NA) %>%
  add_row(P_relative = c(1,32.25/100,0,50.375/100,0,36.6/100),N_relative = c(0,46/100,1,33.435/100,0,51.7/100),K_relative = c(0,21.75/100,0,16.19/100,1,11.7/100),Line1 = c(1,1,NA,NA,NA,NA),Line2 = c(NA,NA,1,1,NA,NA),Line3 = c(NA,NA,NA,NA,1,1))

droplastsix = tail(which(is.na(ds_npk_figuremaking$pH_class)), 6)
acid <- ggtern(data=ds_npk_figuremaking,aes(x=P_relative,y=N_relative,z=K_relative))+ 
  geom_point(aes(fill=pH_class),color="black",size=2,shape=21) +
  geom_point(data=ds_npk_figuremaking[droplastsix,], aes(x=P_relative, y=N_relative, z=K_relative),
             color="white", size=2, shape=21) +
  scale_fill_gradient(low="yellow",high="red",na.value = NA) +
  scale_color_gradient(low="yellow",high="red",na.value = NA) +
  theme_rgbw() +
  theme(legend.justification=c(0,1), legend.position=c(0,1),plot.tag = element_text(face = "bold",size = 24),text = element_text(size = 17)) + 
  guides(fill = guide_colorbar(order=1),alpha= guide_legend(order=2),color="none") +
  labs(fill = "pH class",alpha="|V - 0|")+
  Tlab("",labelarrow="10P/(N+10P+K)")+
  Tlab("",labelarrow="N/(N+10P+K)")+
  Llab("",labelarrow="10P/(N+10P+K)")+
  Rlab("",labelarrow="K/(N+10P+K)")+
  geom_path(aes(size=Line1),color="black")+
  geom_path(aes(size=Line2),color="black")+
  geom_path(aes(size=Line3),color="black")+
  geom_path(aes(size=Line3*10),color="black",alpha=0)+
  guides(fill = guide_colorbar(order = 1),alpha = guide_legend(order = 2),color = "none",size = "none") +
  labs(tag = "(c)") +
  annotate("text", x=1.8, y=0.3, z=1.75, label="N limitation", size=6, color="black") +
  annotate("text", x=0.07, y=0.55, z=0.53, label="P/P+N limitation", size=6, color="black", angle = -60) +
  annotate("text", x=0.57, y=0.67, z=0.04, label="K/K+N limitation", size=6, color="black", angle = 60)

# N deposition

ds_npk_filtered = ds_npk[!is.na(ds_npk$Ndep), ]

ds_npk_figuremaking = ds_npk_filtered %>%
  mutate(Line1 = NA) %>%
  mutate(Line2 = NA) %>%
  mutate(Line3 = NA) %>%
  add_row(P_relative = c(1,32.25/100,0,50.375/100,0,36.6/100),N_relative = c(0,46/100,1,33.435/100,0,51.7/100),K_relative = c(0,21.75/100,0,16.19/100,1,11.7/100),Line1 = c(1,1,NA,NA,NA,NA),Line2 = c(NA,NA,1,1,NA,NA),Line3 = c(NA,NA,NA,NA,1,1))

droplastsix = tail(which(is.na(ds_npk_figuremaking$Ndep)), 6)
Ndeposition <- ggtern(data=ds_npk_figuremaking,aes(x=P_relative,y=N_relative,z=K_relative))+ 
  geom_point(aes(fill=Ndep),color="black",size=2,shape=21) +
  geom_point(data=ds_npk_figuremaking[droplastsix,], aes(x=P_relative, y=N_relative, z=K_relative),
             color="white", size=2, shape=21) +
  scale_fill_gradient(low="yellow",high="red",na.value = NA) +
  scale_color_gradient(low="yellow",high="red",na.value = NA) +
  theme_rgbw() +
  theme(legend.justification=c(0,1), legend.position=c(0,1),plot.tag = element_text(face = "bold",size = 24),text = element_text(size = 17)) + 
  guides(fill = guide_colorbar(order=1),alpha= guide_legend(order=2),color="none") +
  labs(fill = expression(paste("N deposition\n(kg/ha.yr)")), alpha="|V - 0|")+
  Tlab("", labelarrow="10P/(N+10P+K)") +
  Tlab("",labelarrow="10P/(N+10P+K)")+
  Tlab("",labelarrow="N/(N+10P+K)")+
  Llab("",labelarrow="10P/(N+10P+K)")+
  Rlab("",labelarrow="K/(N+10P+K)")+
  geom_path(aes(size=Line1),color="black")+
  geom_path(aes(size=Line2),color="black")+
  geom_path(aes(size=Line3),color="black")+
  geom_path(aes(size=Line3*10),color="black",alpha=0)+
  guides(fill = guide_colorbar(order = 1),alpha = guide_legend(order = 2),color = "none",size = "none") +
  labs(tag = "(d)",plot.tag.position = c(0.1, 0.5)) +
  annotate("text", x=1.8, y=0.3, z=1.75, label="N limitation", size=6, color="black") +
  annotate("text", x=0.07, y=0.55, z=0.53, label="P/P+N limitation", size=6, color="black", angle = -60) +
  annotate("text", x=0.57, y=0.67, z=0.04, label="K/K+N limitation", size=6, color="black", angle = 60)

library(ggtern)
tiff("Fig1.tiff", units="in", width=13.97, height=13.97, res=600)
ggtern::grid.arrange(grid.arrange(tgraph,moist,ncol=2),
                     grid.arrange(acid,Ndeposition,ncol=2),
                     nrow=2, heights= c(6,6))
dev.off()

###################

rm(list=ls())
  