ds_npk = read.csv("npk_dataset.csv",header = T)
attach(ds_npk)

library(tidyverse)

###### Supplementary results: characterization of habitat types #########
### Extended Data Fig. 1: Distribution of environmental gradients per habitat type

library(lmerTest)
lm1 = lmer(Moisture_ell ~ Habitat + (1 | Location), data = ds_npk)
hist(residuals(lm1))
shapiro.test(residuals(lm1))
anova(lm1)
summary(lm1)

library(ordinal)
lm1 = clmm(as.factor(pH_class) ~ Habitat + (1 | Location), data = ds_npk)
lm1_reduced = clmm(as.factor(pH_class) ~ (1 | Location), data = ds_npk)
anova(lm1_reduced,lm1)
summary(lm1)

library(lsmeans)
lsmeans(lm1, pairwise ~ Habitat, adjust="tukey")

###### Supplementary results: nutrient stoichiometry among habitat types #########
### Fig. 2a & Extended Data Fig. 2: Patterns of vegetation N:P, N:K and K:P stoichiometry (g g-1) across habitat types

NP_critical = NP - 14.5
NK_critical = NK - 2.1
logNK_critical = log(NK) - log(2.1)
KP_critical = KP - 3.4
lm1 = lmer(logNK_critical ~ Habitat + (1|Location) - 1)
hist(logNK_critical)
shapiro.test(residuals(lm1))
anova(lm1)
summary(lm1)

lsmeans(lm1, pairwise ~ Habitat, adjust="tukey")

###### Results: nutrient limitation among habitat types #########
### Fig. 2b: Patterns of nutrient limitation types across habitat types

ds_npk_nponly = ds_npk %>%
  filter(Limitation %in% c("P/PN", "N")) %>%
  mutate(Limitation_encoded = ifelse(Limitation == "N",0,1))
lm1 = glmer(Limitation_encoded ~ Habitat + (1|Location),data = ds_npk_nponly,family = binomial)
anova(lm1)
summary(lm1)

pr = ds_npk %>%
  filter(Limitation %in% c("P/PN", "N")) %>%
  group_by(Habitat) %>%
  summarize(total_count = n(),
            ppn_count = sum(Limitation == "P/PN")) %>%
  mutate(proportion = ppn_count / total_count) %>%
  mutate(ncount = total_count - ppn_count)
lm1<-glm(proportion ~ Habitat,family=binomial,weight=total_count,data=pr)
pchisq(0,0,lower.tail=F)
anova(lm1,test="Chisq")

library(lsmeans)
lsmeans(lm1, pairwise ~ Habitat, adjust="tukey")

###### Results: nutrient limitation and environmental gradients #########
### Table 1, Fig. 3, Extended Data Tables 2 & 3, Extended Data Fig. 3

## Simple regression & ANOVA - Table 1, Extended Data Fig. 3

lm1 = lmer(NP ~ I(pH_class^2) + pH_class + (1|Location))
summary(lm1)
shapiro.test(residuals(lm1))
hist(residuals(lm1))

r2_values <- performance::r2(lm1)
print(r2_values)

lm1 = lmer(NP ~ pH_class_name + (1|Location),data = ds_npk)
hist(residuals(lm1))
shapiro.test(residuals(lm1))
anova(lm1)

library(lsmeans)
lsmeans(lm1, pairwise ~ pH_class_name, adjust="tukey")

## Multiple regression - Extended Data Tables 2 & 3
# Look for potential interactions among explanatory variables
library(tree)
model = tree(NP ~ Moisture_ell + pH_class + I(pH_class^2) + Ndep)
plot(model)
text(model)
model2 = prune.tree(model)
plot(model2)
model3 = prune.tree(model,best=5)
plot(model3)
text(model3)

lm1 = lmer(NP ~ Moisture_ell + pH_class + I(pH_class^2) + Ndep + Moisture_ell:pH_class + Moisture_ell:I(pH_class^2) + (1|Location))
lm1 = lmer(NP ~ Moisture_ell + pH_class + I(pH_class^2) + Ndep + Moisture_ell:pH_class + (1|Location))
lm1 = lmer(NP ~ Moisture_ell + pH_class + I(pH_class^2) + Moisture_ell:pH_class + (1|Location))
lm1 = lmer(NP ~ Moisture_ell + pH_class + I(pH_class^2) + (1|Location))
shapiro.test(residuals(lm1))
summary(lm1)

library(car)
lm1.fixed = lm(NP ~ Moisture_ell + pH_class)
vif(lm1.fixed)

r2_values <- performance::r2(lm1)
print(r2_values)
library(partR2)
partial_R2 <- partR2(lm1, data = ds_npk,partvars = c("Moisture_ell","pH_class","I(pH_class^2)"), 
                     R2_type = "marginal", nboot = 10)
partial_R2 <- partR2(lm1, data = ds_npk,partvars = c("Moisture_ell","pH_class","I(pH_class^2)"), 
                     R2_type = "conditional", nboot = 10)
partial_R2

# Example on nutrient limitation types
ds_npk_Limitations = ds_npk %>%
  filter(Limitation %in% c("P/PN", "N", "K/KN")) %>%
  mutate(Limitation_N = ifelse(Limitation == "N",1,0)) %>%
  mutate(Limitation_PPN = ifelse(Limitation == "P/PN",1,0)) %>%
  mutate(Limitation_KKN = ifelse(Limitation == "K/KN",1,0))

lm1 = glmer(Limitation_N ~ Ndep + Moisture_ell + pH_water + I(pH_water^2) + (1|Location),data = ds_npk_Limitations,family = binomial)
summary(lm1)
shapiro.test(residuals(lm1))

library(DHARMa)
# tests if the overall distribution conforms to expectations
testUniformity(lm1)
# tests if there are more simulation outliers than expected
testOutliers(lm1)
# tests if the simulated dispersion is equal to the observed dispersion
testDispersion(lm1) 
# fits a quantile regression or residuals against a predictor (default predicted value), and tests of this conforms to the expected quantile
testQuantiles(lm1)
# tests residuals against a categorical predictor
#testCategorical(simulationOutput, catPred = testData$group)
# tests if there are more zeros in the data than expected from the simulations
testZeroInflation(lm1)

# Check for spatial autocorrelation
library(spdep)
library(ggplot2)
library(sp)
library(geosphere)
library(lme4)

ds_npk_Limitations_autocorrcheck = ds_npk_Limitations %>%
  select(Limitation_N,Ndep,pH_water,Moisture_ell,Location,Latitude,Longitude)

ds_npk_Limitations_autocorrcheck <- na.omit(ds_npk_Limitations_autocorrcheck)  # Remove rows with any NA values
coordinates <- cbind(ds_npk_Limitations_autocorrcheck$Longitude, ds_npk_Limitations_autocorrcheck$Latitude)
# Fit the model with complete cases
lm1 <- glmer(Limitation_N ~ Ndep + Moisture_ell + I(pH_water^2) + pH_water + (1|Location), data = ds_npk_Limitations_autocorrcheck, family = binomial)
# Extract residuals
residuals_lm1 <- residuals(lm1)
# Visualize the data points
ggplot(ds_npk_Limitations, aes(x = Longitude, y = Latitude)) +
  geom_point() +
  theme_minimal() +
  ggtitle("Spatial Distribution of Data Points")
# Calculate distances using the Haversine formula
dist_matrix <- distm(coordinates, fun = distHaversine)  # Distance in meters
distances <- as.vector(dist_matrix / 1000)  # Convert to kilometers
# Plot histogram of pairwise distances
hist(distances, breaks = 30, main = "Histogram of Pairwise Distances", xlab = "Distance (km)")
# Calculate mean nearest neighbor distance
nn_distances <- apply(dist_matrix / 1000, 1, function(row) sort(row)[2])  # Second closest point (excluding self)
mean_nn_distance <- mean(nn_distances)
# Choose initial maximum distance as twice the mean nearest neighbor distance
max_distance <- mean_nn_distance * 2  # Adjust this factor as needed
increase_factor <- 1.1  # Factor by which to increase the distance if needed
# Create the neighbors list and ensure each point has neighbors
repeat {
  nb <- dnearneigh(coordinates, 0, max_distance, longlat = TRUE)
  no_neighbor_indices <- which(sapply(nb, length) == 0)
  
  if (length(no_neighbor_indices) == 0) break  # Exit loop if all points have neighbors
  # Increase max_distance to ensure all points have at least one neighbor
  max_distance <- max_distance * increase_factor
}
# Handle any remaining isolated points
no_neighbor_indices <- which(sapply(nb, length) == 0)
if (length(no_neighbor_indices) > 0) {
  for (i in no_neighbor_indices) {
    # Find the closest neighbor manually
    distances_to_others <- dist_matrix[i, ] / 1000
    closest_neighbor <- which.min(distances_to_others[-i])
    
    # Add the closest neighbor to the list
    nb[[i]] <- closest_neighbor
  }
}
# Convert the neighbors list to a weights list object with zero.policy = TRUE
listw <- nb2listw(nb, style = "W", zero.policy = TRUE)
# Verify matching lengths of residuals and weights list
if (length(residuals_lm1) != length(listw$neighbours)) {
  stop("Lengths of residuals and weights list do not match")
}
# Calculate Moran's I for the residuals with zero.policy = TRUE
moran_test <- moran.test(residuals_lm1, listw, zero.policy = TRUE)
# Print the result
print(moran_test)

r2_values <- performance::r2(lm1)
print(r2_values)

library(partR2)
partial_R2 <- partR2(lm1, data = ds_npk_Limitations,partvars = c("Ndep","Moisture_ell","pH_water","I(pH_water^2)"), 
                     R2_type = "marginal")
#, nboot = 10)
partial_R2 <- partR2(lm1, data = ds_npk_Limitations,partvars = c("Ndep","Moisture_ell","pH_water","I(pH_water^2)"), 
                     R2_type = "conditional")
#, nboot = 10)
partial_R2

###### Results: which nutrient drives the limitation? #########
### Fig. 4, Extended Data Table 4: Variation in vegetation N:P:K stoichiometry (g g-1) and limitation types explained by concentrations of individual nutrients

# Plant 'nutrient' vs 'ratio'
PN = 1/NP
PK = 1/KP
KN = 1/NK
lm1 = lmer(Kplant ~ NK + Habitat + NK:Habitat + (1|Location))
anova(lm1)
summary(lm1)
shapiro.test(residuals(lm1))
r2_values <- performance::r2(lm1)
print(r2_values)

# Plant 'nutrient' vs 'limitation type
# Random effects perspective (not interested in habitat types)
lm1 = lmer(Kplant ~ Limitation + (1|Location) + (1|Habitat))
anova(lm1)
summary(lm1)
shapiro.test(residuals(lm1))
boxplot(Kplant ~ Limitation)

library(lsmeans)
lsmeans(lm1, pairwise ~ Limitation, adjust="tukey")

# Correlations among nutrient concentrations
hist(Kplant)
shapiro.test(Pplant)
cor.test(Pplant,Kplant)

#########################################

detach(ds_npk)
rm(list=ls())

#########################################
